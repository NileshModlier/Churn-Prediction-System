import pytest
from httpx import AsyncClient
from src.api import app

@pytest.mark.asyncio
async def test_predict():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        payload = {"feature1":0.5, "feature2":0.3, "feature3":0.1}
        r = await ac.post('/predict', json=payload)
        assert r.status_code == 200
        assert 'probability' in r.json()
        assert 'prediction' in r.json()
