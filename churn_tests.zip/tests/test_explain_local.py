import pytest
from httpx import AsyncClient
from src.api import app

@pytest.mark.asyncio
async def test_explain_local():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        r = await ac.get('/explain_local?idx=0')
        assert r.status_code == 200
        assert 'explanation_plot' in r.json()
