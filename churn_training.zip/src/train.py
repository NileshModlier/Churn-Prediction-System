import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle, os
from .config import MODEL_PATH, TEST_DATA

# generate synthetic data for demo
import numpy as np
np.random.seed(42)
X = pd.DataFrame({
    'feature1': np.random.rand(200),
    'feature2': np.random.rand(200),
    'feature3': np.random.rand(200)
})
y = np.random.randint(0,2,200)

def train_model():
    model = RandomForestClassifier()
    model.fit(X, y)
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(model, f)
    df = X.copy(); df['label'] = y
    df.to_csv(TEST_DATA, index=False)
    print("Training complete → model saved.")

if __name__ == '__main__':
    train_model()
