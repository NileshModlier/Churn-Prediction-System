MODEL_PATH = "artifacts/model.pkl"
TEST_DATA = "data/test.csv"
