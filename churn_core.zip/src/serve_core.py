from fastapi import FastAPI

app = FastAPI(title="Churn Prediction Core")

@app.get('/health')
def h(): return {"ok": True}
