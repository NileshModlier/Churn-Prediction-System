from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd
import pickle
from .config import MODEL_PATH, TEST_DATA
from .shap_analysis import explain_local

app = FastAPI(title="Churn Prediction API")

# Load model
with open(MODEL_PATH, 'rb') as f:
    model = pickle.load(f)

df = pd.read_csv(TEST_DATA)
X = df.drop(columns=['label'])

class Features(BaseModel):
    feature1: float
    feature2: float
    feature3: float

@app.get('/health')
def health():
    return {"ok": True}

@app.post('/predict')
def predict(features: Features):
    try:
        data = pd.DataFrame([features.dict()])
        prob = model.predict_proba(data)[0][1]
        pred = int(prob >= 0.5)
        return {"probability": float(prob), "prediction": pred}
    except Exception as e:
        raise HTTPException(400, str(e))

@app.get('/explain_local')
def explain(idx: int = 0):
    try:
        path = explain_local(idx)
        return {"explanation_plot": path}
    except Exception as e:
        raise HTTPException(400, str(e))
