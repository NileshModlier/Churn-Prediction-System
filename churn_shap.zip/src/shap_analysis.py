import shap
import pandas as pd
import pickle
import os
import matplotlib.pyplot as plt
from .config import MODEL_PATH, TEST_DATA

PLOTS_DIR = 'artifacts/plots'
os.makedirs(PLOTS_DIR, exist_ok=True)

TARGET_COL = 'label'

def run_global_shap():
    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)
    df = pd.read_csv(TEST_DATA)
    X = df.drop(columns=[TARGET_COL])
    explainer = shap.Explainer(model, X)
    sv = explainer(X)
    plt.figure()
    shap.plots.beeswarm(sv, show=False)
    plt.savefig(os.path.join(PLOTS_DIR,'beeswarm.png'))
    plt.close()
    plt.figure()
    shap.plots.bar(sv, show=False)
    plt.savefig(os.path.join(PLOTS_DIR,'feature_importance.png'))
    plt.close()
    print('Global SHAP plots saved.')

def explain_local(idx=0):
    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)
    df = pd.read_csv(TEST_DATA)
    X = df.drop(columns=[TARGET_COL])
    row = X.iloc[[idx]]
    explainer = shap.Explainer(model, X)
    sv = explainer(row)
    out_path = os.path.join(PLOTS_DIR,f'local_row_{idx}.png')
    plt.figure()
    shap.plots.waterfall(sv[0], show=False)
    plt.savefig(out_path)
    plt.close()
    return out_path
